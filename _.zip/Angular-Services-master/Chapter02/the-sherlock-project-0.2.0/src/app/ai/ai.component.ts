import {Component} from '@angular/core';

@Component({
  selector: 'sh-ai',
  templateUrl: './ai.html'
})
export class AiComponent {
}
