import {Component} from '@angular/core';

@Component({
  selector: 'sh-accuracy',
  templateUrl: './accuracy.html'
})
export class AccuracyComponent {

}
