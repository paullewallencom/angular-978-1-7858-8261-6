import {Component} from '@angular/core';

@Component({
  selector: 'sh-report',
  templateUrl: './report.html'
})
export class ReportComponent {

}
