import {Component} from '@angular/core';

@Component({
  selector: 'sh-collector',
  templateUrl: './collector.html'
})
export class CollectorComponent {
}
