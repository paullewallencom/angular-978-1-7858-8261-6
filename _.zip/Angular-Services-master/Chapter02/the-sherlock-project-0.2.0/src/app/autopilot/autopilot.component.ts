import {Component} from '@angular/core';

@Component({
  selector: 'sh-autopilot',
  templateUrl: './autopilot.html'
})
export class AutopilotComponent {

}
