import {Component} from '@angular/core';

@Component({
  selector: 'sh-rating',
  templateUrl: './rating.html'
})
export class RatingComponent {
}
