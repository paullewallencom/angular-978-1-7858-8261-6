import {Component} from '@angular/core';

@Component({
  selector: 'sh-nav',
  templateUrl: './navigation.html'
})
export class NavigationComponent {}
