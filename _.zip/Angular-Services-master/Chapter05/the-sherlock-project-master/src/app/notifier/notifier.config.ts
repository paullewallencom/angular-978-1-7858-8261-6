export class NotifierConfig {
  constructor(
    public notify: boolean,
    public notifier: string,
    public threshold: string
  ) {}
}
